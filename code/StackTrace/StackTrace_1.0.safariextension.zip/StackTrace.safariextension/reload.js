// from http://stackoverflow.com/a/4673436/5244995
// First, checks if it isn't implemented yet.
if (!String.prototype.format) {
  String.prototype.format = function() {
    var args = arguments;
    return this.replace(/{(\d+)}/g, function(match, number) { 
      return typeof args[number] != 'undefined'
        ? args[number]
        : match
      ;
    });
  };
}
// end from

var STACK_API_URL = 'https://api.stackexchange.com/2.2';

$.ajaxSetup({
  dataType:"text", // not JSON because it gets turned into the string "[object Object]" when saved
});

function on_update(no_sched) {
//   alert("reloading (schedule next: "+ (!no_sched).toString() + ")");
  var user_id = safari.extension.settings.userID;
//   var old_badge = 10;
  var buttons = safari.extension.toolbarItems;
  var site = safari.extension.settings.siteName
  var button;
  for (var i = 0; i < buttons.length; ++i) {
    if (buttons[i].identifier == "stackTrace") {
//       old_badge = buttons[i].badge;
//       buttons[i].badge = 00;
      button = buttons[i];
      break;
    }
  }
//   alert(button.image);
  button.image =  safari.extension.baseURI + "toolbar/icon-working.png";
 
  $.get(STACK_API_URL+"/users/"+user_id+"?site="+site+"&filter=!40DJoyoFxZjdE2bLQ", function(data) {
    localStorage.current_info = data;
//     alert(JSON.parse(data).items[0].reputation)
//     alert(localStorage.old_rep);
    if (JSON.parse(data).items[0].reputation != localStorage.old_rep) {
//       old_badge++;
        button.badge++;
        localStorage.old_rep = JSON.parse(data).items[0].reputation;
    }
  }).always(function() {
    if (!no_sched || (new Date()-localStorage.last_update > (safari.extension.settings.updateInterval+5)*60000.0)) {
      setTimeout(on_update, safari.extension.settings.updateInterval*60000.0); // interval in minutes
    }
    setTimeout(function() {button.image = safari.extension.baseURI + "toolbar/icon.png"}, 5000);
    localStorage.last_update = new Date();
  }).done(function() {
//     alert("OK");
    button.image = safari.extension.baseURI + "toolbar/icon-success.png";
  }).fail(function(a, b, c, d) {
    button.image = safari.extension.baseURI + "toolbar/icon-fail.png";
  });
}

on_update() // kick off the cycle

