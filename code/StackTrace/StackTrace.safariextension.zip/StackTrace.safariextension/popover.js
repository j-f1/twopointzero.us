// from http://stackoverflow.com/a/4673436/5244995
// First, checks if it isn't implemented yet.
if (!String.prototype.format) {
  String.prototype.format = function() {
    var args = arguments;
    return this.replace(/{(\d+)}/g, function(match, number) { 
      return typeof args[number] != 'undefined'
        ? args[number]
        : match
      ;
    });
  };
}
// end from

safari.application.addEventListener("popover", function(event) {
  $body = $(event.target.contentWindow.document.body);
  event.target.width = 331;
  event.target.height = 140;
 
  if (!localStorage.current_info) {
    alert("The data hasn't arrived. You might want to check that your user ID is entered correctly.");
//     event.preventDefault();
//     event.stopPropagation();
    return;
  }
//   alert(JSON);
//   alert(localStorage.current_info);
  var data = JSON.parse(localStorage.current_info);
  var user_data = data.items[0];
  var badges = user_data.badge_counts;
  
  var $profileLink    = $body.find("#profile")      ,
      $pic            = $body.find("#pic")          ,
      $name           = $body.find("#name")         ,
      $badgeTotal     = $body.find("#totalBadges")  ,
      $bronze         = $body.find("#bronzeBadges") ,
      $silver         = $body.find("#silverBadges") ,
      $gold           = $body.find("#goldBadges")   ,
      $rep            = $body.find("#currentRep")   ,
      $dRep           = $body.find("#deltaRep")     ,
      $quotaLabel     = $body.find("#quotaLabel")   ,
      $quotaProgress  = $body.find("#quotaProgress");
      
  $profileLink.attr("href", "http://"+ safari.extension.settings.siteName+"/users/"+safari.extension.settings.userID)
  alert($profileLink.attr("href"));
  $pic.attr("src", user_data.profile_image)
  $name.text(user_data.display_name)
  
  var gold_badges   = badges.gold  ,
      silver_badges = badges.silver,
      bronze_badges = badges.bronze,
      total_badges  = gold_badges+silver_badges+bronze_badges;
  
  $badgeTotal.text(total_badges.toString());
  $gold.text(gold_badges.toString());
  $silver.text(silver_badges.toString());
  $bronze.text(bronze_badges.toString());
  
  var old_rep = localStorage.old_rep ? localStorage.old_rep : user_data.reputation;
  $rep.text(user_data.reputation);
  $dRep.show();
  var prefix = "";
  var dRep = user_data.reputation - old_rep;
  if (dRep > 0) {
    prefix = "+";
    $dRep.css("background-color", "#008000");
  } else if (dRep < 0) {
    prefix = "–";
    $dRep.css("background-color", "#800000");
  } else if (dRep === 0) {
      $dRep.hide();
  } else {alert("Your computer’s logic is broken!!!!!");return;}
  // good dRep: #008000
  // bad  dRep: #800000
  
  $dRep.text(prefix+dRep);
  
  localStorage.old_rep = user_data.reputation;
  
  var quota = data.quota_max,
      current = data.quota_remaining;
  $quotaLabel.text('{0} of {1} left'.format(current, quota));
  $quotaProgress.css("width", (1-((quota-current)/quota))*100+"%");  
  
  var buttons = safari.extension.toolbarItems;
  for (var i = 0; i < buttons.length; ++i) {
    if (buttons[i].identifier == "stackTrace") {
      buttons[i].badge = 0;
    }
  }
}, true);
